﻿
namespace discordAIO6
{
    partial class dAIOmain
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dAIOmain));
            this.sidePanel = new System.Windows.Forms.Panel();
            this.page2 = new System.Windows.Forms.Label();
            this.page1 = new System.Windows.Forms.Label();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.btnInventory = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.ratButton = new System.Windows.Forms.Button();
            this.btnParty = new System.Windows.Forms.Button();
            this.btnMap = new System.Windows.Forms.Button();
            this.btnWork = new System.Windows.Forms.Button();
            this.qrButton = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.logoBox = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.settingsSite = new System.Windows.Forms.Panel();
            this.saveButton = new System.Windows.Forms.Button();
            this.translateLabel = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.turkishButton = new System.Windows.Forms.Button();
            this.spanishButton = new System.Windows.Forms.Button();
            this.polishButton = new System.Windows.Forms.Button();
            this.frenchButton = new System.Windows.Forms.Button();
            this.russianButton = new System.Windows.Forms.Button();
            this.englishButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.shNo = new System.Windows.Forms.Button();
            this.btnUpdates = new System.Windows.Forms.Button();
            this.shYes = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.redButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.versionLabel = new System.Windows.Forms.Label();
            this.checkingLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mainSite = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.buildingLabel = new System.Windows.Forms.Label();
            this.embedBox = new System.Windows.Forms.PictureBox();
            this.colorSelect = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cloneButton = new System.Windows.Forms.Button();
            this.generateButton = new System.Windows.Forms.Button();
            this.fileinfoLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buildButton = new System.Windows.Forms.Button();
            this.iconUpload = new System.Windows.Forms.Button();
            this.iconBox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.webhookCheck = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.webhookBox = new System.Windows.Forms.TextBox();
            this.navLabel = new System.Windows.Forms.Label();
            this.inspectorSite = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.exportCredentials = new System.Windows.Forms.Button();
            this.winBox = new System.Windows.Forms.TextBox();
            this.tokenBox = new System.Windows.Forms.TextBox();
            this.macBox = new System.Windows.Forms.TextBox();
            this.ipBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dAIOupload = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.dAIObox = new System.Windows.Forms.TextBox();
            this.additionalSite = new System.Windows.Forms.Panel();
            this.wizardBox = new System.Windows.Forms.CheckBox();
            this.nitroBox = new System.Windows.Forms.CheckBox();
            this.cmdBox = new System.Windows.Forms.CheckBox();
            this.ratBox = new System.Windows.Forms.CheckBox();
            this.dinternetBox = new System.Windows.Forms.CheckBox();
            this.pluginSource = new ScintillaNET.Scintilla();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.fakeMessageBox = new System.Windows.Forms.TextBox();
            this.faketitleBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.ransomBox = new System.Windows.Forms.CheckBox();
            this.cryptoBox = new System.Windows.Forms.CheckBox();
            this.sbrhisBox = new System.Windows.Forms.CheckBox();
            this.swifiBox = new System.Windows.Forms.CheckBox();
            this.sVpnBox = new System.Windows.Forms.CheckBox();
            this.sbrCookiesBox = new System.Windows.Forms.CheckBox();
            this.sbrpassBox = new System.Windows.Forms.CheckBox();
            this.swinkeyBox = new System.Windows.Forms.CheckBox();
            this.inputdBox = new System.Windows.Forms.CheckBox();
            this.jumpscareBox = new System.Windows.Forms.CheckBox();
            this.hidesBox = new System.Windows.Forms.CheckBox();
            this.blockerBox = new System.Windows.Forms.CheckBox();
            this.pluginBox = new System.Windows.Forms.CheckBox();
            this.bsodBox = new System.Windows.Forms.CheckBox();
            this.taskmanagerBox = new System.Windows.Forms.CheckBox();
            this.defenderBox = new System.Windows.Forms.CheckBox();
            this.startupBox = new System.Windows.Forms.CheckBox();
            this.errorBox = new System.Windows.Forms.CheckBox();
            this.obfuscateBox = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.pumpBox = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.pumpButton = new System.Windows.Forms.Button();
            this.miscSite = new System.Windows.Forms.Panel();
            this.tVLabel = new System.Windows.Forms.Label();
            this.tMFALabel = new System.Windows.Forms.Label();
            this.tIDLabel = new System.Windows.Forms.Label();
            this.tPhoneLabel = new System.Windows.Forms.Label();
            this.tEmailLabel = new System.Windows.Forms.Label();
            this.tNameLabel = new System.Windows.Forms.Label();
            this.avatarBox = new System.Windows.Forms.PictureBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.flooderEmbed = new System.Windows.Forms.PictureBox();
            this.flooderEmSelect = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.safeBox = new System.Windows.Forms.CheckBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.wdeleteButton = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.userBox = new System.Windows.Forms.TextBox();
            this.tokenChecker = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.TokenCheckerBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.miscWebhookBox = new System.Windows.Forms.TextBox();
            this.gbBox = new System.Windows.Forms.CheckBox();
            this.mbBox = new System.Windows.Forms.CheckBox();
            this.kbBox = new System.Windows.Forms.CheckBox();
            this.pumpPathBox = new System.Windows.Forms.TextBox();
            this.minerSite = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.ratSite = new System.Windows.Forms.Panel();
            this.ratCompileButton = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.insertButton = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.pipBox = new System.Windows.Forms.CheckBox();
            this.label42 = new System.Windows.Forms.Label();
            this.ratTokenBox = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.ratInstallButton = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.rURLBox = new System.Windows.Forms.TextBox();
            this.qrSite = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.qrStartBtn = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.minimizeBtn = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.fixButton = new System.Windows.Forms.Button();
            this.sidePanel.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).BeginInit();
            this.settingsSite.SuspendLayout();
            this.mainSite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.embedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconBox)).BeginInit();
            this.inspectorSite.SuspendLayout();
            this.additionalSite.SuspendLayout();
            this.miscSite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avatarBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flooderEmbed)).BeginInit();
            this.minerSite.SuspendLayout();
            this.ratSite.SuspendLayout();
            this.qrSite.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(8)))));
            this.sidePanel.Controls.Add(this.page2);
            this.sidePanel.Controls.Add(this.page1);
            this.sidePanel.Controls.Add(this.pnlNav);
            this.sidePanel.Controls.Add(this.btnInventory);
            this.sidePanel.Controls.Add(this.btnSettings);
            this.sidePanel.Controls.Add(this.ratButton);
            this.sidePanel.Controls.Add(this.btnParty);
            this.sidePanel.Controls.Add(this.btnMap);
            this.sidePanel.Controls.Add(this.btnWork);
            this.sidePanel.Controls.Add(this.qrButton);
            this.sidePanel.Controls.Add(this.btnDashboard);
            this.sidePanel.Controls.Add(this.panel2);
            this.sidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidePanel.Location = new System.Drawing.Point(0, 0);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(186, 577);
            this.sidePanel.TabIndex = 1;
            // 
            // page2
            // 
            this.page2.AutoSize = true;
            this.page2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.page2.Font = new System.Drawing.Font("Poppins", 7F);
            this.page2.ForeColor = System.Drawing.Color.DarkRed;
            this.page2.Location = new System.Drawing.Point(167, 429);
            this.page2.Name = "page2";
            this.page2.Size = new System.Drawing.Size(14, 17);
            this.page2.TabIndex = 4;
            this.page2.Text = "2";
            this.page2.Click += new System.EventHandler(this.page2_Click);
            // 
            // page1
            // 
            this.page1.AutoSize = true;
            this.page1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.page1.Font = new System.Drawing.Font("Poppins Medium", 7F, System.Drawing.FontStyle.Bold);
            this.page1.ForeColor = System.Drawing.Color.DarkRed;
            this.page1.Location = new System.Drawing.Point(156, 429);
            this.page1.Name = "page1";
            this.page1.Size = new System.Drawing.Size(12, 17);
            this.page1.TabIndex = 4;
            this.page1.Text = "1";
            this.page1.Click += new System.EventHandler(this.page1_Click);
            // 
            // pnlNav
            // 
            this.pnlNav.BackColor = System.Drawing.Color.DarkRed;
            this.pnlNav.Location = new System.Drawing.Point(3, 182);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(3, 100);
            this.pnlNav.TabIndex = 3;
            // 
            // btnInventory
            // 
            this.btnInventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInventory.FlatAppearance.BorderSize = 0;
            this.btnInventory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInventory.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnInventory.ForeColor = System.Drawing.Color.DarkRed;
            this.btnInventory.Location = new System.Drawing.Point(0, 192);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(186, 42);
            this.btnInventory.TabIndex = 2;
            this.btnInventory.Text = "Additional";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            this.btnInventory.Leave += new System.EventHandler(this.btnInventory_Leave);
            // 
            // btnSettings
            // 
            this.btnSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnSettings.ForeColor = System.Drawing.Color.DarkRed;
            this.btnSettings.Location = new System.Drawing.Point(0, 535);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(186, 42);
            this.btnSettings.TabIndex = 2;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            this.btnSettings.Leave += new System.EventHandler(this.btnSettings_Leave);
            // 
            // ratButton
            // 
            this.ratButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ratButton.FlatAppearance.BorderSize = 0;
            this.ratButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratButton.Font = new System.Drawing.Font("Poppins", 10F);
            this.ratButton.ForeColor = System.Drawing.Color.DarkRed;
            this.ratButton.Location = new System.Drawing.Point(0, 384);
            this.ratButton.Name = "ratButton";
            this.ratButton.Size = new System.Drawing.Size(186, 42);
            this.ratButton.TabIndex = 2;
            this.ratButton.Text = "RAT";
            this.ratButton.UseVisualStyleBackColor = true;
            this.ratButton.Click += new System.EventHandler(this.ratButton_Click);
            this.ratButton.Leave += new System.EventHandler(this.ratButton_Leave);
            // 
            // btnParty
            // 
            this.btnParty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnParty.FlatAppearance.BorderSize = 0;
            this.btnParty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParty.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnParty.ForeColor = System.Drawing.Color.DarkRed;
            this.btnParty.Location = new System.Drawing.Point(0, 336);
            this.btnParty.Name = "btnParty";
            this.btnParty.Size = new System.Drawing.Size(186, 42);
            this.btnParty.TabIndex = 2;
            this.btnParty.Text = "Miner";
            this.btnParty.UseVisualStyleBackColor = true;
            this.btnParty.Click += new System.EventHandler(this.btnParty_Click);
            this.btnParty.Leave += new System.EventHandler(this.btnParty_Leave);
            // 
            // btnMap
            // 
            this.btnMap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMap.FlatAppearance.BorderSize = 0;
            this.btnMap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMap.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnMap.ForeColor = System.Drawing.Color.DarkRed;
            this.btnMap.Location = new System.Drawing.Point(0, 288);
            this.btnMap.Name = "btnMap";
            this.btnMap.Size = new System.Drawing.Size(186, 42);
            this.btnMap.TabIndex = 2;
            this.btnMap.Text = "Misc";
            this.btnMap.UseVisualStyleBackColor = true;
            this.btnMap.Click += new System.EventHandler(this.btnMap_Click);
            this.btnMap.Leave += new System.EventHandler(this.btnMap_Leave);
            // 
            // btnWork
            // 
            this.btnWork.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWork.FlatAppearance.BorderSize = 0;
            this.btnWork.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWork.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnWork.ForeColor = System.Drawing.Color.DarkRed;
            this.btnWork.Location = new System.Drawing.Point(0, 240);
            this.btnWork.Name = "btnWork";
            this.btnWork.Size = new System.Drawing.Size(186, 42);
            this.btnWork.TabIndex = 2;
            this.btnWork.Text = "Inspector";
            this.btnWork.UseVisualStyleBackColor = true;
            this.btnWork.Click += new System.EventHandler(this.btnWork_Click);
            this.btnWork.Leave += new System.EventHandler(this.btnWork_Leave);
            // 
            // qrButton
            // 
            this.qrButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qrButton.FlatAppearance.BorderSize = 0;
            this.qrButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qrButton.Font = new System.Drawing.Font("Poppins", 10F);
            this.qrButton.ForeColor = System.Drawing.Color.DarkRed;
            this.qrButton.Location = new System.Drawing.Point(0, 144);
            this.qrButton.Name = "qrButton";
            this.qrButton.Size = new System.Drawing.Size(186, 42);
            this.qrButton.TabIndex = 1;
            this.qrButton.Text = "QR Grabber";
            this.qrButton.UseVisualStyleBackColor = true;
            this.qrButton.Click += new System.EventHandler(this.qrButton_Click);
            this.qrButton.Leave += new System.EventHandler(this.qrButton_Leave);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Poppins", 10F);
            this.btnDashboard.ForeColor = System.Drawing.Color.DarkRed;
            this.btnDashboard.Location = new System.Drawing.Point(0, 144);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(186, 42);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Main";
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            this.btnDashboard.Leave += new System.EventHandler(this.btnDashboard_Leave);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.usernameLabel);
            this.panel2.Controls.Add(this.logoBox);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 144);
            this.panel2.TabIndex = 1;
            // 
            // usernameLabel
            // 
            this.usernameLabel.Font = new System.Drawing.Font("Poppins", 10F);
            this.usernameLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.usernameLabel.Location = new System.Drawing.Point(34, 97);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(118, 25);
            this.usernameLabel.TabIndex = 2;
            this.usernameLabel.Text = "Your Username";
            this.usernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logoBox
            // 
            this.logoBox.Image = ((System.Drawing.Image)(resources.GetObject("logoBox.Image")));
            this.logoBox.Location = new System.Drawing.Point(60, 22);
            this.logoBox.Name = "logoBox";
            this.logoBox.Size = new System.Drawing.Size(63, 63);
            this.logoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoBox.TabIndex = 1;
            this.logoBox.TabStop = false;
            this.logoBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.DarkRed;
            this.btnExit.Location = new System.Drawing.Point(914, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(25, 25);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // settingsSite
            // 
            this.settingsSite.Controls.Add(this.saveButton);
            this.settingsSite.Controls.Add(this.translateLabel);
            this.settingsSite.Controls.Add(this.label39);
            this.settingsSite.Controls.Add(this.turkishButton);
            this.settingsSite.Controls.Add(this.spanishButton);
            this.settingsSite.Controls.Add(this.polishButton);
            this.settingsSite.Controls.Add(this.frenchButton);
            this.settingsSite.Controls.Add(this.russianButton);
            this.settingsSite.Controls.Add(this.englishButton);
            this.settingsSite.Controls.Add(this.label47);
            this.settingsSite.Controls.Add(this.label7);
            this.settingsSite.Controls.Add(this.button3);
            this.settingsSite.Controls.Add(this.shNo);
            this.settingsSite.Controls.Add(this.fixButton);
            this.settingsSite.Controls.Add(this.btnUpdates);
            this.settingsSite.Controls.Add(this.shYes);
            this.settingsSite.Controls.Add(this.button2);
            this.settingsSite.Controls.Add(this.button1);
            this.settingsSite.Controls.Add(this.redButton);
            this.settingsSite.Controls.Add(this.label5);
            this.settingsSite.Controls.Add(this.versionLabel);
            this.settingsSite.Controls.Add(this.checkingLabel);
            this.settingsSite.Controls.Add(this.label3);
            this.settingsSite.Controls.Add(this.label2);
            this.settingsSite.Controls.Add(this.label1);
            this.settingsSite.Location = new System.Drawing.Point(193, 43);
            this.settingsSite.Name = "settingsSite";
            this.settingsSite.Size = new System.Drawing.Size(751, 522);
            this.settingsSite.TabIndex = 4;
            // 
            // saveButton
            // 
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saveButton.FlatAppearance.BorderSize = 0;
            this.saveButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.saveButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveButton.Font = new System.Drawing.Font("Poppins", 13F);
            this.saveButton.ForeColor = System.Drawing.Color.DarkRed;
            this.saveButton.Location = new System.Drawing.Point(611, 457);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(116, 37);
            this.saveButton.TabIndex = 21;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // translateLabel
            // 
            this.translateLabel.AutoSize = true;
            this.translateLabel.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.translateLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.translateLabel.Location = new System.Drawing.Point(311, 474);
            this.translateLabel.Name = "translateLabel";
            this.translateLabel.Size = new System.Drawing.Size(32, 23);
            this.translateLabel.TabIndex = 19;
            this.translateLabel.Text = "null";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label39.ForeColor = System.Drawing.Color.DarkRed;
            this.label39.Location = new System.Drawing.Point(44, 443);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(257, 56);
            this.label39.TabIndex = 18;
            this.label39.Text = "Discord: discord.gg/qjrDprutvg\r\nGithub: github.com/Nyxonn";
            // 
            // turkishButton
            // 
            this.turkishButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.turkishButton.FlatAppearance.BorderSize = 0;
            this.turkishButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.turkishButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.turkishButton.ForeColor = System.Drawing.Color.DarkRed;
            this.turkishButton.Location = new System.Drawing.Point(546, 239);
            this.turkishButton.Name = "turkishButton";
            this.turkishButton.Size = new System.Drawing.Size(71, 28);
            this.turkishButton.TabIndex = 17;
            this.turkishButton.Text = "Türk";
            this.turkishButton.UseVisualStyleBackColor = true;
            this.turkishButton.Click += new System.EventHandler(this.turkishButton_Click);
            // 
            // spanishButton
            // 
            this.spanishButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.spanishButton.FlatAppearance.BorderSize = 0;
            this.spanishButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spanishButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.spanishButton.ForeColor = System.Drawing.Color.DarkRed;
            this.spanishButton.Location = new System.Drawing.Point(469, 239);
            this.spanishButton.Name = "spanishButton";
            this.spanishButton.Size = new System.Drawing.Size(71, 28);
            this.spanishButton.TabIndex = 16;
            this.spanishButton.Text = "Español";
            this.spanishButton.UseVisualStyleBackColor = true;
            this.spanishButton.Click += new System.EventHandler(this.spanishButton_Click);
            // 
            // polishButton
            // 
            this.polishButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.polishButton.FlatAppearance.BorderSize = 0;
            this.polishButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.polishButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.polishButton.ForeColor = System.Drawing.Color.DarkRed;
            this.polishButton.Location = new System.Drawing.Point(392, 239);
            this.polishButton.Name = "polishButton";
            this.polishButton.Size = new System.Drawing.Size(71, 28);
            this.polishButton.TabIndex = 15;
            this.polishButton.Text = "Polski";
            this.polishButton.UseVisualStyleBackColor = true;
            this.polishButton.Click += new System.EventHandler(this.polishButton_Click);
            // 
            // frenchButton
            // 
            this.frenchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.frenchButton.FlatAppearance.BorderSize = 0;
            this.frenchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.frenchButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.frenchButton.ForeColor = System.Drawing.Color.DarkRed;
            this.frenchButton.Location = new System.Drawing.Point(315, 239);
            this.frenchButton.Name = "frenchButton";
            this.frenchButton.Size = new System.Drawing.Size(71, 28);
            this.frenchButton.TabIndex = 14;
            this.frenchButton.Text = "Français";
            this.frenchButton.UseVisualStyleBackColor = true;
            this.frenchButton.Click += new System.EventHandler(this.frenchButton_Click);
            // 
            // russianButton
            // 
            this.russianButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.russianButton.FlatAppearance.BorderSize = 0;
            this.russianButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.russianButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.russianButton.ForeColor = System.Drawing.Color.DarkRed;
            this.russianButton.Location = new System.Drawing.Point(238, 239);
            this.russianButton.Name = "russianButton";
            this.russianButton.Size = new System.Drawing.Size(71, 28);
            this.russianButton.TabIndex = 13;
            this.russianButton.Text = "русский";
            this.russianButton.UseVisualStyleBackColor = true;
            this.russianButton.Click += new System.EventHandler(this.russianButton_Click);
            // 
            // englishButton
            // 
            this.englishButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.englishButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.englishButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.englishButton.ForeColor = System.Drawing.Color.DarkRed;
            this.englishButton.Location = new System.Drawing.Point(161, 239);
            this.englishButton.Name = "englishButton";
            this.englishButton.Size = new System.Drawing.Size(71, 28);
            this.englishButton.TabIndex = 12;
            this.englishButton.Text = "English";
            this.englishButton.UseVisualStyleBackColor = true;
            this.englishButton.Click += new System.EventHandler(this.englishButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.DarkRed;
            this.label7.Location = new System.Drawing.Point(40, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 34);
            this.label7.TabIndex = 11;
            this.label7.Text = "Language:";
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Poppins", 9F);
            this.button3.ForeColor = System.Drawing.Color.Gainsboro;
            this.button3.Location = new System.Drawing.Point(373, 90);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(71, 28);
            this.button3.TabIndex = 10;
            this.button3.Text = "White";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // shNo
            // 
            this.shNo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.shNo.FlatAppearance.BorderSize = 0;
            this.shNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shNo.Font = new System.Drawing.Font("Poppins", 9F);
            this.shNo.ForeColor = System.Drawing.Color.DarkRed;
            this.shNo.Location = new System.Drawing.Point(283, 140);
            this.shNo.Name = "shNo";
            this.shNo.Size = new System.Drawing.Size(58, 28);
            this.shNo.TabIndex = 9;
            this.shNo.Text = "No";
            this.shNo.UseVisualStyleBackColor = true;
            this.shNo.Click += new System.EventHandler(this.shNo_Click);
            // 
            // btnUpdates
            // 
            this.btnUpdates.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdates.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdates.Font = new System.Drawing.Font("Poppins", 9F);
            this.btnUpdates.ForeColor = System.Drawing.Color.DarkRed;
            this.btnUpdates.Location = new System.Drawing.Point(216, 188);
            this.btnUpdates.Name = "btnUpdates";
            this.btnUpdates.Size = new System.Drawing.Size(58, 28);
            this.btnUpdates.TabIndex = 8;
            this.btnUpdates.Text = "Check";
            this.btnUpdates.UseVisualStyleBackColor = true;
            this.btnUpdates.Click += new System.EventHandler(this.btnUpdates_Click);
            // 
            // shYes
            // 
            this.shYes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.shYes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shYes.Font = new System.Drawing.Font("Poppins", 9F);
            this.shYes.ForeColor = System.Drawing.Color.DarkRed;
            this.shYes.Location = new System.Drawing.Point(219, 140);
            this.shYes.Name = "shYes";
            this.shYes.Size = new System.Drawing.Size(58, 28);
            this.shYes.TabIndex = 8;
            this.shYes.Text = "Yes";
            this.shYes.UseVisualStyleBackColor = true;
            this.shYes.Click += new System.EventHandler(this.shYes_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Poppins", 9F);
            this.button2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.button2.Location = new System.Drawing.Point(296, 90);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(71, 28);
            this.button2.TabIndex = 7;
            this.button2.Text = "Blue";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Poppins", 9F);
            this.button1.ForeColor = System.Drawing.Color.LimeGreen;
            this.button1.Location = new System.Drawing.Point(219, 90);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 28);
            this.button1.TabIndex = 6;
            this.button1.Text = "Green";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // redButton
            // 
            this.redButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.redButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.redButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.redButton.ForeColor = System.Drawing.Color.DarkRed;
            this.redButton.Location = new System.Drawing.Point(142, 90);
            this.redButton.Name = "redButton";
            this.redButton.Size = new System.Drawing.Size(71, 28);
            this.redButton.TabIndex = 5;
            this.redButton.Text = "Red";
            this.redButton.UseVisualStyleBackColor = true;
            this.redButton.Click += new System.EventHandler(this.redButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Location = new System.Drawing.Point(40, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(170, 34);
            this.label5.TabIndex = 4;
            this.label5.Text = "Check-updates:";
            // 
            // versionLabel
            // 
            this.versionLabel.AutoSize = true;
            this.versionLabel.Font = new System.Drawing.Font("Poppins SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.versionLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.versionLabel.Location = new System.Drawing.Point(136, 36);
            this.versionLabel.Name = "versionLabel";
            this.versionLabel.Size = new System.Drawing.Size(61, 34);
            this.versionLabel.TabIndex = 3;
            this.versionLabel.Text = "0.6.0";
            // 
            // checkingLabel
            // 
            this.checkingLabel.AutoSize = true;
            this.checkingLabel.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.checkingLabel.Location = new System.Drawing.Point(196, 23);
            this.checkingLabel.Name = "checkingLabel";
            this.checkingLabel.Size = new System.Drawing.Size(32, 23);
            this.checkingLabel.TabIndex = 20;
            this.checkingLabel.Text = "null";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(40, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 34);
            this.label3.TabIndex = 2;
            this.label3.Text = "Show username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(40, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "UI Color:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(40, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Version:";
            // 
            // mainSite
            // 
            this.mainSite.Controls.Add(this.label38);
            this.mainSite.Controls.Add(this.buildingLabel);
            this.mainSite.Controls.Add(this.embedBox);
            this.mainSite.Controls.Add(this.colorSelect);
            this.mainSite.Controls.Add(this.label9);
            this.mainSite.Controls.Add(this.cloneButton);
            this.mainSite.Controls.Add(this.generateButton);
            this.mainSite.Controls.Add(this.fileinfoLabel);
            this.mainSite.Controls.Add(this.label8);
            this.mainSite.Controls.Add(this.buildButton);
            this.mainSite.Controls.Add(this.iconUpload);
            this.mainSite.Controls.Add(this.iconBox);
            this.mainSite.Controls.Add(this.label6);
            this.mainSite.Controls.Add(this.webhookCheck);
            this.mainSite.Controls.Add(this.label4);
            this.mainSite.Controls.Add(this.webhookBox);
            this.mainSite.Location = new System.Drawing.Point(193, 43);
            this.mainSite.Name = "mainSite";
            this.mainSite.Size = new System.Drawing.Size(751, 522);
            this.mainSite.TabIndex = 5;
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.label38.Location = new System.Drawing.Point(639, 13);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(67, 29);
            this.label38.TabIndex = 16;
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buildingLabel
            // 
            this.buildingLabel.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buildingLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.buildingLabel.Location = new System.Drawing.Point(35, 386);
            this.buildingLabel.Name = "buildingLabel";
            this.buildingLabel.Size = new System.Drawing.Size(692, 73);
            this.buildingLabel.TabIndex = 15;
            this.buildingLabel.Text = "Idle...";
            this.buildingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // embedBox
            // 
            this.embedBox.BackColor = System.Drawing.Color.DarkRed;
            this.embedBox.Location = new System.Drawing.Point(206, 166);
            this.embedBox.Name = "embedBox";
            this.embedBox.Size = new System.Drawing.Size(63, 63);
            this.embedBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.embedBox.TabIndex = 14;
            this.embedBox.TabStop = false;
            // 
            // colorSelect
            // 
            this.colorSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.colorSelect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.colorSelect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.colorSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colorSelect.Font = new System.Drawing.Font("Poppins", 8F);
            this.colorSelect.ForeColor = System.Drawing.Color.DarkRed;
            this.colorSelect.Location = new System.Drawing.Point(206, 235);
            this.colorSelect.Name = "colorSelect";
            this.colorSelect.Size = new System.Drawing.Size(83, 24);
            this.colorSelect.TabIndex = 13;
            this.colorSelect.Text = "Select";
            this.colorSelect.UseVisualStyleBackColor = true;
            this.colorSelect.Click += new System.EventHandler(this.colorSelect_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.Color.DarkRed;
            this.label9.Location = new System.Drawing.Point(201, 139);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 28);
            this.label9.TabIndex = 12;
            this.label9.Text = "Embed color";
            // 
            // cloneButton
            // 
            this.cloneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cloneButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cloneButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cloneButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cloneButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.cloneButton.ForeColor = System.Drawing.Color.DarkRed;
            this.cloneButton.Location = new System.Drawing.Point(129, 324);
            this.cloneButton.Name = "cloneButton";
            this.cloneButton.Size = new System.Drawing.Size(83, 24);
            this.cloneButton.TabIndex = 11;
            this.cloneButton.Text = "Clone";
            this.cloneButton.UseVisualStyleBackColor = true;
            this.cloneButton.Click += new System.EventHandler(this.cloneButton_Click);
            // 
            // generateButton
            // 
            this.generateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.generateButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.generateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.generateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.generateButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.generateButton.ForeColor = System.Drawing.Color.DarkRed;
            this.generateButton.Location = new System.Drawing.Point(40, 324);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(83, 24);
            this.generateButton.TabIndex = 10;
            this.generateButton.Text = "Generate";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // fileinfoLabel
            // 
            this.fileinfoLabel.AutoSize = true;
            this.fileinfoLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fileinfoLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.fileinfoLabel.Location = new System.Drawing.Point(137, 293);
            this.fileinfoLabel.Name = "fileinfoLabel";
            this.fileinfoLabel.Size = new System.Drawing.Size(58, 28);
            this.fileinfoLabel.TabIndex = 9;
            this.fileinfoLabel.Text = "None";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.DarkRed;
            this.label8.Location = new System.Drawing.Point(35, 293);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 28);
            this.label8.TabIndex = 8;
            this.label8.Text = "Metadata:";
            // 
            // buildButton
            // 
            this.buildButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buildButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buildButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buildButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buildButton.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buildButton.ForeColor = System.Drawing.Color.DarkRed;
            this.buildButton.Location = new System.Drawing.Point(315, 466);
            this.buildButton.Name = "buildButton";
            this.buildButton.Size = new System.Drawing.Size(134, 33);
            this.buildButton.TabIndex = 7;
            this.buildButton.Text = "Build";
            this.buildButton.UseVisualStyleBackColor = true;
            this.buildButton.Click += new System.EventHandler(this.buildButton_Click);
            // 
            // iconUpload
            // 
            this.iconUpload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconUpload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.iconUpload.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.iconUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconUpload.Font = new System.Drawing.Font("Poppins", 8F);
            this.iconUpload.ForeColor = System.Drawing.Color.DarkRed;
            this.iconUpload.Location = new System.Drawing.Point(40, 237);
            this.iconUpload.Name = "iconUpload";
            this.iconUpload.Size = new System.Drawing.Size(83, 24);
            this.iconUpload.TabIndex = 6;
            this.iconUpload.Text = "Upload";
            this.iconUpload.UseVisualStyleBackColor = true;
            this.iconUpload.Click += new System.EventHandler(this.iconUpload_Click);
            // 
            // iconBox
            // 
            this.iconBox.Image = global::discordAIO6.Properties.Resources.none;
            this.iconBox.Location = new System.Drawing.Point(40, 166);
            this.iconBox.Name = "iconBox";
            this.iconBox.Size = new System.Drawing.Size(63, 63);
            this.iconBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.iconBox.TabIndex = 5;
            this.iconBox.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.DarkRed;
            this.label6.Location = new System.Drawing.Point(35, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 28);
            this.label6.TabIndex = 4;
            this.label6.Text = "Icon";
            // 
            // webhookCheck
            // 
            this.webhookCheck.Cursor = System.Windows.Forms.Cursors.Hand;
            this.webhookCheck.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.webhookCheck.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.webhookCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.webhookCheck.Font = new System.Drawing.Font("Poppins", 8F);
            this.webhookCheck.ForeColor = System.Drawing.Color.DarkRed;
            this.webhookCheck.Location = new System.Drawing.Point(542, 88);
            this.webhookCheck.Name = "webhookCheck";
            this.webhookCheck.Size = new System.Drawing.Size(83, 24);
            this.webhookCheck.TabIndex = 3;
            this.webhookCheck.Text = "Check";
            this.webhookCheck.UseVisualStyleBackColor = true;
            this.webhookCheck.Click += new System.EventHandler(this.webhookCheck_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(35, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 28);
            this.label4.TabIndex = 2;
            this.label4.Text = "Webhook";
            // 
            // webhookBox
            // 
            this.webhookBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.webhookBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.webhookBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.webhookBox.ForeColor = System.Drawing.Color.DarkRed;
            this.webhookBox.Location = new System.Drawing.Point(37, 88);
            this.webhookBox.Name = "webhookBox";
            this.webhookBox.Size = new System.Drawing.Size(499, 24);
            this.webhookBox.TabIndex = 1;
            // 
            // navLabel
            // 
            this.navLabel.AutoSize = true;
            this.navLabel.Font = new System.Drawing.Font("Poppins Medium", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.navLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.navLabel.Location = new System.Drawing.Point(196, 12);
            this.navLabel.Name = "navLabel";
            this.navLabel.Size = new System.Drawing.Size(74, 37);
            this.navLabel.TabIndex = 6;
            this.navLabel.Text = "Main";
            // 
            // inspectorSite
            // 
            this.inspectorSite.Controls.Add(this.label16);
            this.inspectorSite.Controls.Add(this.exportCredentials);
            this.inspectorSite.Controls.Add(this.winBox);
            this.inspectorSite.Controls.Add(this.tokenBox);
            this.inspectorSite.Controls.Add(this.macBox);
            this.inspectorSite.Controls.Add(this.ipBox);
            this.inspectorSite.Controls.Add(this.nameBox);
            this.inspectorSite.Controls.Add(this.label15);
            this.inspectorSite.Controls.Add(this.label13);
            this.inspectorSite.Controls.Add(this.label12);
            this.inspectorSite.Controls.Add(this.label11);
            this.inspectorSite.Controls.Add(this.label10);
            this.inspectorSite.Controls.Add(this.dAIOupload);
            this.inspectorSite.Controls.Add(this.label14);
            this.inspectorSite.Controls.Add(this.dAIObox);
            this.inspectorSite.Location = new System.Drawing.Point(193, 43);
            this.inspectorSite.Name = "inspectorSite";
            this.inspectorSite.Size = new System.Drawing.Size(751, 522);
            this.inspectorSite.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(35, 375);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 28);
            this.label16.TabIndex = 12;
            this.label16.Text = "Export (as .txt)";
            // 
            // exportCredentials
            // 
            this.exportCredentials.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exportCredentials.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.exportCredentials.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.exportCredentials.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportCredentials.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.exportCredentials.ForeColor = System.Drawing.Color.DarkRed;
            this.exportCredentials.Location = new System.Drawing.Point(46, 433);
            this.exportCredentials.Name = "exportCredentials";
            this.exportCredentials.Size = new System.Drawing.Size(123, 30);
            this.exportCredentials.TabIndex = 11;
            this.exportCredentials.Text = "Credentials";
            this.exportCredentials.UseVisualStyleBackColor = true;
            this.exportCredentials.Click += new System.EventHandler(this.exportCredentials_Click);
            // 
            // winBox
            // 
            this.winBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.winBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.winBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.winBox.ForeColor = System.Drawing.Color.DarkRed;
            this.winBox.Location = new System.Drawing.Point(190, 293);
            this.winBox.Name = "winBox";
            this.winBox.ReadOnly = true;
            this.winBox.Size = new System.Drawing.Size(391, 24);
            this.winBox.TabIndex = 10;
            // 
            // tokenBox
            // 
            this.tokenBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.tokenBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tokenBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tokenBox.ForeColor = System.Drawing.Color.DarkRed;
            this.tokenBox.Location = new System.Drawing.Point(200, 252);
            this.tokenBox.Name = "tokenBox";
            this.tokenBox.ReadOnly = true;
            this.tokenBox.Size = new System.Drawing.Size(381, 24);
            this.tokenBox.TabIndex = 10;
            // 
            // macBox
            // 
            this.macBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.macBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.macBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.macBox.ForeColor = System.Drawing.Color.DarkRed;
            this.macBox.Location = new System.Drawing.Point(232, 211);
            this.macBox.Name = "macBox";
            this.macBox.ReadOnly = true;
            this.macBox.Size = new System.Drawing.Size(349, 24);
            this.macBox.TabIndex = 10;
            // 
            // ipBox
            // 
            this.ipBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.ipBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ipBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ipBox.ForeColor = System.Drawing.Color.DarkRed;
            this.ipBox.Location = new System.Drawing.Point(208, 174);
            this.ipBox.Name = "ipBox";
            this.ipBox.ReadOnly = true;
            this.ipBox.Size = new System.Drawing.Size(373, 24);
            this.ipBox.TabIndex = 10;
            // 
            // nameBox
            // 
            this.nameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.nameBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nameBox.ForeColor = System.Drawing.Color.DarkRed;
            this.nameBox.Location = new System.Drawing.Point(174, 136);
            this.nameBox.Name = "nameBox";
            this.nameBox.ReadOnly = true;
            this.nameBox.Size = new System.Drawing.Size(407, 24);
            this.nameBox.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.ForeColor = System.Drawing.Color.DarkRed;
            this.label15.Location = new System.Drawing.Point(92, 293);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 28);
            this.label15.TabIndex = 8;
            this.label15.Text = "WIN Key:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(92, 252);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 28);
            this.label13.TabIndex = 7;
            this.label13.Text = "DC Token:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.Color.DarkRed;
            this.label12.Location = new System.Drawing.Point(92, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 28);
            this.label12.TabIndex = 6;
            this.label12.Text = "MAC Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.Color.DarkRed;
            this.label11.Location = new System.Drawing.Point(92, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 28);
            this.label11.TabIndex = 5;
            this.label11.Text = "IP Address:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.Color.DarkRed;
            this.label10.Location = new System.Drawing.Point(92, 135);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 28);
            this.label10.TabIndex = 4;
            this.label10.Text = "Name:";
            // 
            // dAIOupload
            // 
            this.dAIOupload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dAIOupload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dAIOupload.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dAIOupload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dAIOupload.Font = new System.Drawing.Font("Poppins", 8F);
            this.dAIOupload.ForeColor = System.Drawing.Color.DarkRed;
            this.dAIOupload.Location = new System.Drawing.Point(542, 67);
            this.dAIOupload.Name = "dAIOupload";
            this.dAIOupload.Size = new System.Drawing.Size(83, 24);
            this.dAIOupload.TabIndex = 3;
            this.dAIOupload.Text = "Upload";
            this.dAIOupload.UseVisualStyleBackColor = true;
            this.dAIOupload.Click += new System.EventHandler(this.dAIOupload_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.ForeColor = System.Drawing.Color.DarkRed;
            this.label14.Location = new System.Drawing.Point(35, 39);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 28);
            this.label14.TabIndex = 2;
            this.label14.Text = ".dAIO";
            // 
            // dAIObox
            // 
            this.dAIObox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.dAIObox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dAIObox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dAIObox.ForeColor = System.Drawing.Color.DarkRed;
            this.dAIObox.Location = new System.Drawing.Point(37, 67);
            this.dAIObox.Name = "dAIObox";
            this.dAIObox.ReadOnly = true;
            this.dAIObox.Size = new System.Drawing.Size(499, 24);
            this.dAIObox.TabIndex = 1;
            // 
            // additionalSite
            // 
            this.additionalSite.Controls.Add(this.wizardBox);
            this.additionalSite.Controls.Add(this.nitroBox);
            this.additionalSite.Controls.Add(this.cmdBox);
            this.additionalSite.Controls.Add(this.ratBox);
            this.additionalSite.Controls.Add(this.dinternetBox);
            this.additionalSite.Controls.Add(this.pluginSource);
            this.additionalSite.Controls.Add(this.label21);
            this.additionalSite.Controls.Add(this.label20);
            this.additionalSite.Controls.Add(this.fakeMessageBox);
            this.additionalSite.Controls.Add(this.faketitleBox);
            this.additionalSite.Controls.Add(this.label19);
            this.additionalSite.Controls.Add(this.label18);
            this.additionalSite.Controls.Add(this.ransomBox);
            this.additionalSite.Controls.Add(this.cryptoBox);
            this.additionalSite.Controls.Add(this.sbrhisBox);
            this.additionalSite.Controls.Add(this.swifiBox);
            this.additionalSite.Controls.Add(this.sVpnBox);
            this.additionalSite.Controls.Add(this.sbrCookiesBox);
            this.additionalSite.Controls.Add(this.sbrpassBox);
            this.additionalSite.Controls.Add(this.swinkeyBox);
            this.additionalSite.Controls.Add(this.inputdBox);
            this.additionalSite.Controls.Add(this.jumpscareBox);
            this.additionalSite.Controls.Add(this.hidesBox);
            this.additionalSite.Controls.Add(this.blockerBox);
            this.additionalSite.Controls.Add(this.pluginBox);
            this.additionalSite.Controls.Add(this.bsodBox);
            this.additionalSite.Controls.Add(this.taskmanagerBox);
            this.additionalSite.Controls.Add(this.defenderBox);
            this.additionalSite.Controls.Add(this.startupBox);
            this.additionalSite.Controls.Add(this.errorBox);
            this.additionalSite.Controls.Add(this.obfuscateBox);
            this.additionalSite.Controls.Add(this.label17);
            this.additionalSite.Location = new System.Drawing.Point(193, 43);
            this.additionalSite.Name = "additionalSite";
            this.additionalSite.Size = new System.Drawing.Size(751, 522);
            this.additionalSite.TabIndex = 16;
            // 
            // wizardBox
            // 
            this.wizardBox.AutoSize = true;
            this.wizardBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wizardBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wizardBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wizardBox.ForeColor = System.Drawing.Color.DarkRed;
            this.wizardBox.Location = new System.Drawing.Point(174, 250);
            this.wizardBox.Name = "wizardBox";
            this.wizardBox.Size = new System.Drawing.Size(134, 26);
            this.wizardBox.TabIndex = 17;
            this.wizardBox.Text = "Fake Install Wizard";
            this.wizardBox.UseVisualStyleBackColor = true;
            // 
            // nitroBox
            // 
            this.nitroBox.AutoSize = true;
            this.nitroBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nitroBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nitroBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nitroBox.ForeColor = System.Drawing.Color.DarkRed;
            this.nitroBox.Location = new System.Drawing.Point(174, 221);
            this.nitroBox.Name = "nitroBox";
            this.nitroBox.Size = new System.Drawing.Size(110, 26);
            this.nitroBox.TabIndex = 17;
            this.nitroBox.Text = "Fake Nitro Gen";
            this.nitroBox.UseVisualStyleBackColor = true;
            // 
            // cmdBox
            // 
            this.cmdBox.AutoSize = true;
            this.cmdBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdBox.ForeColor = System.Drawing.Color.DarkRed;
            this.cmdBox.Location = new System.Drawing.Point(174, 193);
            this.cmdBox.Name = "cmdBox";
            this.cmdBox.Size = new System.Drawing.Size(83, 26);
            this.cmdBox.TabIndex = 17;
            this.cmdBox.Text = "Fake CMD";
            this.cmdBox.UseVisualStyleBackColor = true;
            // 
            // ratBox
            // 
            this.ratBox.AutoSize = true;
            this.ratBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ratBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ratBox.ForeColor = System.Drawing.Color.DarkRed;
            this.ratBox.Location = new System.Drawing.Point(177, 457);
            this.ratBox.Name = "ratBox";
            this.ratBox.Size = new System.Drawing.Size(94, 26);
            this.ratBox.TabIndex = 16;
            this.ratBox.Text = "Discord RAT";
            this.ratBox.UseVisualStyleBackColor = true;
            // 
            // dinternetBox
            // 
            this.dinternetBox.AutoSize = true;
            this.dinternetBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dinternetBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dinternetBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dinternetBox.ForeColor = System.Drawing.Color.DarkRed;
            this.dinternetBox.Location = new System.Drawing.Point(177, 487);
            this.dinternetBox.Name = "dinternetBox";
            this.dinternetBox.Size = new System.Drawing.Size(117, 26);
            this.dinternetBox.TabIndex = 16;
            this.dinternetBox.Text = "Disable internet";
            this.dinternetBox.UseVisualStyleBackColor = true;
            // 
            // pluginSource
            // 
            this.pluginSource.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pluginSource.Location = new System.Drawing.Point(392, 187);
            this.pluginSource.Name = "pluginSource";
            this.pluginSource.Size = new System.Drawing.Size(335, 296);
            this.pluginSource.TabIndex = 15;
            this.pluginSource.Text = "string message = \"Discord AIO\";\r\nMessageBox.Show(message);\r\n";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Poppins", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.ForeColor = System.Drawing.Color.DarkRed;
            this.label21.Location = new System.Drawing.Point(648, 102);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 26);
            this.label21.TabIndex = 14;
            this.label21.Text = "Message";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Poppins", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.ForeColor = System.Drawing.Color.DarkRed;
            this.label20.Location = new System.Drawing.Point(648, 61);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 26);
            this.label20.TabIndex = 13;
            this.label20.Text = "Title";
            // 
            // fakeMessageBox
            // 
            this.fakeMessageBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.fakeMessageBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fakeMessageBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fakeMessageBox.ForeColor = System.Drawing.Color.DarkRed;
            this.fakeMessageBox.Location = new System.Drawing.Point(392, 101);
            this.fakeMessageBox.Name = "fakeMessageBox";
            this.fakeMessageBox.Size = new System.Drawing.Size(250, 24);
            this.fakeMessageBox.TabIndex = 12;
            // 
            // faketitleBox
            // 
            this.faketitleBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.faketitleBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.faketitleBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.faketitleBox.ForeColor = System.Drawing.Color.DarkRed;
            this.faketitleBox.Location = new System.Drawing.Point(392, 61);
            this.faketitleBox.Name = "faketitleBox";
            this.faketitleBox.Size = new System.Drawing.Size(250, 24);
            this.faketitleBox.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.ForeColor = System.Drawing.Color.DarkRed;
            this.label19.Location = new System.Drawing.Point(387, 156);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 28);
            this.label19.TabIndex = 10;
            this.label19.Text = "Custom plugin";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.ForeColor = System.Drawing.Color.DarkRed;
            this.label18.Location = new System.Drawing.Point(387, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(91, 28);
            this.label18.TabIndex = 9;
            this.label18.Text = "Fake error";
            // 
            // ransomBox
            // 
            this.ransomBox.AutoSize = true;
            this.ransomBox.Cursor = System.Windows.Forms.Cursors.No;
            this.ransomBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ransomBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ransomBox.ForeColor = System.Drawing.Color.DimGray;
            this.ransomBox.Location = new System.Drawing.Point(174, 113);
            this.ransomBox.Name = "ransomBox";
            this.ransomBox.Size = new System.Drawing.Size(104, 26);
            this.ransomBox.TabIndex = 8;
            this.ransomBox.Text = "Ransomware";
            this.ransomBox.UseVisualStyleBackColor = true;
            // 
            // cryptoBox
            // 
            this.cryptoBox.AutoSize = true;
            this.cryptoBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cryptoBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cryptoBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cryptoBox.ForeColor = System.Drawing.Color.DarkRed;
            this.cryptoBox.Location = new System.Drawing.Point(174, 86);
            this.cryptoBox.Name = "cryptoBox";
            this.cryptoBox.Size = new System.Drawing.Size(103, 26);
            this.cryptoBox.TabIndex = 7;
            this.cryptoBox.Text = "Crypto miner";
            this.cryptoBox.UseVisualStyleBackColor = true;
            // 
            // sbrhisBox
            // 
            this.sbrhisBox.AutoSize = true;
            this.sbrhisBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sbrhisBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sbrhisBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sbrhisBox.ForeColor = System.Drawing.Color.DarkRed;
            this.sbrhisBox.Location = new System.Drawing.Point(174, 59);
            this.sbrhisBox.Name = "sbrhisBox";
            this.sbrhisBox.Size = new System.Drawing.Size(148, 26);
            this.sbrhisBox.TabIndex = 6;
            this.sbrhisBox.Text = "Steal browser history";
            this.sbrhisBox.UseVisualStyleBackColor = true;
            // 
            // swifiBox
            // 
            this.swifiBox.AutoSize = true;
            this.swifiBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.swifiBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.swifiBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.swifiBox.ForeColor = System.Drawing.Color.DarkRed;
            this.swifiBox.Location = new System.Drawing.Point(46, 487);
            this.swifiBox.Name = "swifiBox";
            this.swifiBox.Size = new System.Drawing.Size(113, 26);
            this.swifiBox.TabIndex = 5;
            this.swifiBox.Text = "Steal WiFi data";
            this.swifiBox.UseVisualStyleBackColor = true;
            // 
            // sVpnBox
            // 
            this.sVpnBox.AutoSize = true;
            this.sVpnBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sVpnBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sVpnBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sVpnBox.ForeColor = System.Drawing.Color.DarkRed;
            this.sVpnBox.Location = new System.Drawing.Point(46, 457);
            this.sVpnBox.Name = "sVpnBox";
            this.sVpnBox.Size = new System.Drawing.Size(81, 26);
            this.sVpnBox.TabIndex = 5;
            this.sVpnBox.Text = "Steal VPN";
            this.sVpnBox.UseVisualStyleBackColor = true;
            // 
            // sbrCookiesBox
            // 
            this.sbrCookiesBox.AutoSize = true;
            this.sbrCookiesBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sbrCookiesBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sbrCookiesBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sbrCookiesBox.ForeColor = System.Drawing.Color.DarkRed;
            this.sbrCookiesBox.Location = new System.Drawing.Point(46, 427);
            this.sbrCookiesBox.Name = "sbrCookiesBox";
            this.sbrCookiesBox.Size = new System.Drawing.Size(153, 26);
            this.sbrCookiesBox.TabIndex = 5;
            this.sbrCookiesBox.Text = "Steal browser cookies";
            this.sbrCookiesBox.UseVisualStyleBackColor = true;
            // 
            // sbrpassBox
            // 
            this.sbrpassBox.AutoSize = true;
            this.sbrpassBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sbrpassBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sbrpassBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.sbrpassBox.ForeColor = System.Drawing.Color.DarkRed;
            this.sbrpassBox.Location = new System.Drawing.Point(46, 397);
            this.sbrpassBox.Name = "sbrpassBox";
            this.sbrpassBox.Size = new System.Drawing.Size(172, 26);
            this.sbrpassBox.TabIndex = 5;
            this.sbrpassBox.Text = "Steal browser passwords";
            this.sbrpassBox.UseVisualStyleBackColor = true;
            // 
            // swinkeyBox
            // 
            this.swinkeyBox.AutoSize = true;
            this.swinkeyBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.swinkeyBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.swinkeyBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.swinkeyBox.ForeColor = System.Drawing.Color.DarkRed;
            this.swinkeyBox.Location = new System.Drawing.Point(46, 367);
            this.swinkeyBox.Name = "swinkeyBox";
            this.swinkeyBox.Size = new System.Drawing.Size(134, 26);
            this.swinkeyBox.TabIndex = 5;
            this.swinkeyBox.Text = "Steal windows key";
            this.swinkeyBox.UseVisualStyleBackColor = true;
            // 
            // inputdBox
            // 
            this.inputdBox.AutoSize = true;
            this.inputdBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.inputdBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.inputdBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.inputdBox.ForeColor = System.Drawing.Color.DarkRed;
            this.inputdBox.Location = new System.Drawing.Point(46, 337);
            this.inputdBox.Name = "inputdBox";
            this.inputdBox.Size = new System.Drawing.Size(199, 26);
            this.inputdBox.TabIndex = 5;
            this.inputdBox.Text = "Disable mouse and keyboard";
            this.inputdBox.UseVisualStyleBackColor = true;
            // 
            // jumpscareBox
            // 
            this.jumpscareBox.AutoSize = true;
            this.jumpscareBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jumpscareBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jumpscareBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.jumpscareBox.ForeColor = System.Drawing.Color.DarkRed;
            this.jumpscareBox.Location = new System.Drawing.Point(46, 307);
            this.jumpscareBox.Name = "jumpscareBox";
            this.jumpscareBox.Size = new System.Drawing.Size(92, 26);
            this.jumpscareBox.TabIndex = 5;
            this.jumpscareBox.Text = "Jumpscare";
            this.jumpscareBox.UseVisualStyleBackColor = true;
            // 
            // hidesBox
            // 
            this.hidesBox.AutoSize = true;
            this.hidesBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hidesBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hidesBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hidesBox.ForeColor = System.Drawing.Color.DarkRed;
            this.hidesBox.Location = new System.Drawing.Point(46, 278);
            this.hidesBox.Name = "hidesBox";
            this.hidesBox.Size = new System.Drawing.Size(94, 26);
            this.hidesBox.TabIndex = 5;
            this.hidesBox.Text = "Hide stealer";
            this.hidesBox.UseVisualStyleBackColor = true;
            // 
            // blockerBox
            // 
            this.blockerBox.AutoSize = true;
            this.blockerBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.blockerBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blockerBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.blockerBox.ForeColor = System.Drawing.Color.DarkRed;
            this.blockerBox.Location = new System.Drawing.Point(46, 250);
            this.blockerBox.Name = "blockerBox";
            this.blockerBox.Size = new System.Drawing.Size(119, 26);
            this.blockerBox.TabIndex = 5;
            this.blockerBox.Text = "Website blocker";
            this.blockerBox.UseVisualStyleBackColor = true;
            // 
            // pluginBox
            // 
            this.pluginBox.AutoSize = true;
            this.pluginBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pluginBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pluginBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pluginBox.ForeColor = System.Drawing.Color.DarkRed;
            this.pluginBox.Location = new System.Drawing.Point(46, 221);
            this.pluginBox.Name = "pluginBox";
            this.pluginBox.Size = new System.Drawing.Size(114, 26);
            this.pluginBox.TabIndex = 5;
            this.pluginBox.Text = "Custom plugin";
            this.pluginBox.UseVisualStyleBackColor = true;
            // 
            // bsodBox
            // 
            this.bsodBox.AutoSize = true;
            this.bsodBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bsodBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bsodBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bsodBox.ForeColor = System.Drawing.Color.DarkRed;
            this.bsodBox.Location = new System.Drawing.Point(46, 193);
            this.bsodBox.Name = "bsodBox";
            this.bsodBox.Size = new System.Drawing.Size(94, 26);
            this.bsodBox.TabIndex = 5;
            this.bsodBox.Text = "Blue Screen";
            this.bsodBox.UseVisualStyleBackColor = true;
            // 
            // taskmanagerBox
            // 
            this.taskmanagerBox.AutoSize = true;
            this.taskmanagerBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.taskmanagerBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.taskmanagerBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.taskmanagerBox.ForeColor = System.Drawing.Color.DarkRed;
            this.taskmanagerBox.Location = new System.Drawing.Point(46, 166);
            this.taskmanagerBox.Name = "taskmanagerBox";
            this.taskmanagerBox.Size = new System.Drawing.Size(154, 26);
            this.taskmanagerBox.TabIndex = 5;
            this.taskmanagerBox.Text = "Disable Task Manager";
            this.taskmanagerBox.UseVisualStyleBackColor = true;
            // 
            // defenderBox
            // 
            this.defenderBox.AutoSize = true;
            this.defenderBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.defenderBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.defenderBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.defenderBox.ForeColor = System.Drawing.Color.DarkRed;
            this.defenderBox.Location = new System.Drawing.Point(46, 139);
            this.defenderBox.Name = "defenderBox";
            this.defenderBox.Size = new System.Drawing.Size(183, 26);
            this.defenderBox.TabIndex = 5;
            this.defenderBox.Text = "Disable Windows Defender";
            this.defenderBox.UseVisualStyleBackColor = true;
            // 
            // startupBox
            // 
            this.startupBox.AutoSize = true;
            this.startupBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.startupBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.startupBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.startupBox.ForeColor = System.Drawing.Color.DarkRed;
            this.startupBox.Location = new System.Drawing.Point(46, 113);
            this.startupBox.Name = "startupBox";
            this.startupBox.Size = new System.Drawing.Size(113, 26);
            this.startupBox.TabIndex = 5;
            this.startupBox.Text = "Run on startup";
            this.startupBox.UseVisualStyleBackColor = true;
            // 
            // errorBox
            // 
            this.errorBox.AutoSize = true;
            this.errorBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.errorBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.errorBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.errorBox.ForeColor = System.Drawing.Color.DarkRed;
            this.errorBox.Location = new System.Drawing.Point(46, 86);
            this.errorBox.Name = "errorBox";
            this.errorBox.Size = new System.Drawing.Size(83, 26);
            this.errorBox.TabIndex = 5;
            this.errorBox.Text = "Fake error";
            this.errorBox.UseVisualStyleBackColor = true;
            // 
            // obfuscateBox
            // 
            this.obfuscateBox.AutoSize = true;
            this.obfuscateBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.obfuscateBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.obfuscateBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obfuscateBox.ForeColor = System.Drawing.Color.DarkRed;
            this.obfuscateBox.Location = new System.Drawing.Point(46, 59);
            this.obfuscateBox.Name = "obfuscateBox";
            this.obfuscateBox.Size = new System.Drawing.Size(87, 26);
            this.obfuscateBox.TabIndex = 4;
            this.obfuscateBox.Text = "Obfuscate";
            this.obfuscateBox.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.ForeColor = System.Drawing.Color.DarkRed;
            this.label17.Location = new System.Drawing.Point(32, 32);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(161, 28);
            this.label17.TabIndex = 3;
            this.label17.Text = "Additional settings";
            // 
            // pumpBox
            // 
            this.pumpBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.pumpBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pumpBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pumpBox.ForeColor = System.Drawing.Color.DarkRed;
            this.pumpBox.Location = new System.Drawing.Point(37, 67);
            this.pumpBox.Name = "pumpBox";
            this.pumpBox.Size = new System.Drawing.Size(118, 24);
            this.pumpBox.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.ForeColor = System.Drawing.Color.DarkRed;
            this.label28.Location = new System.Drawing.Point(35, 39);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(106, 28);
            this.label28.TabIndex = 2;
            this.label28.Text = "File pumper";
            // 
            // pumpButton
            // 
            this.pumpButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pumpButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pumpButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pumpButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pumpButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.pumpButton.ForeColor = System.Drawing.Color.DarkRed;
            this.pumpButton.Location = new System.Drawing.Point(542, 67);
            this.pumpButton.Name = "pumpButton";
            this.pumpButton.Size = new System.Drawing.Size(83, 24);
            this.pumpButton.TabIndex = 3;
            this.pumpButton.Text = "Pump";
            this.pumpButton.UseVisualStyleBackColor = true;
            this.pumpButton.Click += new System.EventHandler(this.pumpButton_Click);
            // 
            // miscSite
            // 
            this.miscSite.Controls.Add(this.tVLabel);
            this.miscSite.Controls.Add(this.tMFALabel);
            this.miscSite.Controls.Add(this.tIDLabel);
            this.miscSite.Controls.Add(this.tPhoneLabel);
            this.miscSite.Controls.Add(this.tEmailLabel);
            this.miscSite.Controls.Add(this.tNameLabel);
            this.miscSite.Controls.Add(this.avatarBox);
            this.miscSite.Controls.Add(this.button8);
            this.miscSite.Controls.Add(this.label36);
            this.miscSite.Controls.Add(this.label35);
            this.miscSite.Controls.Add(this.label34);
            this.miscSite.Controls.Add(this.label33);
            this.miscSite.Controls.Add(this.label32);
            this.miscSite.Controls.Add(this.label31);
            this.miscSite.Controls.Add(this.label30);
            this.miscSite.Controls.Add(this.flooderEmbed);
            this.miscSite.Controls.Add(this.flooderEmSelect);
            this.miscSite.Controls.Add(this.label27);
            this.miscSite.Controls.Add(this.safeBox);
            this.miscSite.Controls.Add(this.button6);
            this.miscSite.Controls.Add(this.button5);
            this.miscSite.Controls.Add(this.label26);
            this.miscSite.Controls.Add(this.wdeleteButton);
            this.miscSite.Controls.Add(this.label25);
            this.miscSite.Controls.Add(this.label24);
            this.miscSite.Controls.Add(this.textBox2);
            this.miscSite.Controls.Add(this.label23);
            this.miscSite.Controls.Add(this.userBox);
            this.miscSite.Controls.Add(this.tokenChecker);
            this.miscSite.Controls.Add(this.label29);
            this.miscSite.Controls.Add(this.button4);
            this.miscSite.Controls.Add(this.TokenCheckerBox);
            this.miscSite.Controls.Add(this.label22);
            this.miscSite.Controls.Add(this.miscWebhookBox);
            this.miscSite.Controls.Add(this.gbBox);
            this.miscSite.Controls.Add(this.mbBox);
            this.miscSite.Controls.Add(this.kbBox);
            this.miscSite.Controls.Add(this.pumpButton);
            this.miscSite.Controls.Add(this.label28);
            this.miscSite.Controls.Add(this.pumpPathBox);
            this.miscSite.Controls.Add(this.pumpBox);
            this.miscSite.Location = new System.Drawing.Point(193, 43);
            this.miscSite.Name = "miscSite";
            this.miscSite.Size = new System.Drawing.Size(751, 522);
            this.miscSite.TabIndex = 17;
            // 
            // tVLabel
            // 
            this.tVLabel.AutoSize = true;
            this.tVLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tVLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tVLabel.Location = new System.Drawing.Point(497, 349);
            this.tVLabel.Name = "tVLabel";
            this.tVLabel.Size = new System.Drawing.Size(58, 28);
            this.tVLabel.TabIndex = 37;
            this.tVLabel.Text = "None";
            // 
            // tMFALabel
            // 
            this.tMFALabel.AutoSize = true;
            this.tMFALabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tMFALabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tMFALabel.Location = new System.Drawing.Point(469, 316);
            this.tMFALabel.Name = "tMFALabel";
            this.tMFALabel.Size = new System.Drawing.Size(58, 28);
            this.tMFALabel.TabIndex = 36;
            this.tMFALabel.Text = "None";
            // 
            // tIDLabel
            // 
            this.tIDLabel.AutoSize = true;
            this.tIDLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tIDLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tIDLabel.Location = new System.Drawing.Point(451, 283);
            this.tIDLabel.Name = "tIDLabel";
            this.tIDLabel.Size = new System.Drawing.Size(58, 28);
            this.tIDLabel.TabIndex = 35;
            this.tIDLabel.Text = "None";
            // 
            // tPhoneLabel
            // 
            this.tPhoneLabel.AutoSize = true;
            this.tPhoneLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tPhoneLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tPhoneLabel.Location = new System.Drawing.Point(485, 250);
            this.tPhoneLabel.Name = "tPhoneLabel";
            this.tPhoneLabel.Size = new System.Drawing.Size(58, 28);
            this.tPhoneLabel.TabIndex = 34;
            this.tPhoneLabel.Text = "None";
            // 
            // tEmailLabel
            // 
            this.tEmailLabel.AutoSize = true;
            this.tEmailLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tEmailLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tEmailLabel.Location = new System.Drawing.Point(488, 217);
            this.tEmailLabel.Name = "tEmailLabel";
            this.tEmailLabel.Size = new System.Drawing.Size(58, 28);
            this.tEmailLabel.TabIndex = 33;
            this.tEmailLabel.Text = "None";
            // 
            // tNameLabel
            // 
            this.tNameLabel.AutoSize = true;
            this.tNameLabel.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tNameLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.tNameLabel.Location = new System.Drawing.Point(484, 184);
            this.tNameLabel.Name = "tNameLabel";
            this.tNameLabel.Size = new System.Drawing.Size(58, 28);
            this.tNameLabel.TabIndex = 32;
            this.tNameLabel.Text = "None";
            // 
            // avatarBox
            // 
            this.avatarBox.Location = new System.Drawing.Point(647, 297);
            this.avatarBox.Name = "avatarBox";
            this.avatarBox.Size = new System.Drawing.Size(80, 80);
            this.avatarBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.avatarBox.TabIndex = 31;
            this.avatarBox.TabStop = false;
            // 
            // button8
            // 
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Poppins", 8F);
            this.button8.ForeColor = System.Drawing.Color.DarkRed;
            this.button8.Location = new System.Drawing.Point(532, 466);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 24);
            this.button8.TabIndex = 30;
            this.button8.Text = "Delete";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label36.ForeColor = System.Drawing.Color.DarkRed;
            this.label36.Location = new System.Drawing.Point(415, 466);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(111, 28);
            this.label36.TabIndex = 29;
            this.label36.Text = "Delete token";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label35.ForeColor = System.Drawing.Color.DarkRed;
            this.label35.Location = new System.Drawing.Point(415, 349);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(76, 28);
            this.label35.TabIndex = 28;
            this.label35.Text = "Verified:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label34.ForeColor = System.Drawing.Color.DarkRed;
            this.label34.Location = new System.Drawing.Point(415, 316);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(48, 28);
            this.label34.TabIndex = 27;
            this.label34.Text = "MFA:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label33.ForeColor = System.Drawing.Color.DarkRed;
            this.label33.Location = new System.Drawing.Point(415, 283);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 28);
            this.label33.TabIndex = 28;
            this.label33.Text = "ID:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label32.ForeColor = System.Drawing.Color.DarkRed;
            this.label32.Location = new System.Drawing.Point(415, 250);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(64, 28);
            this.label32.TabIndex = 27;
            this.label32.Text = "Phone:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label31.ForeColor = System.Drawing.Color.DarkRed;
            this.label31.Location = new System.Drawing.Point(415, 217);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 28);
            this.label31.TabIndex = 28;
            this.label31.Text = "E-mail:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label30.ForeColor = System.Drawing.Color.DarkRed;
            this.label30.Location = new System.Drawing.Point(415, 184);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(63, 28);
            this.label30.TabIndex = 27;
            this.label30.Text = "Name:";
            // 
            // flooderEmbed
            // 
            this.flooderEmbed.BackColor = System.Drawing.Color.DarkRed;
            this.flooderEmbed.Location = new System.Drawing.Point(214, 346);
            this.flooderEmbed.Name = "flooderEmbed";
            this.flooderEmbed.Size = new System.Drawing.Size(27, 27);
            this.flooderEmbed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flooderEmbed.TabIndex = 26;
            this.flooderEmbed.TabStop = false;
            // 
            // flooderEmSelect
            // 
            this.flooderEmSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flooderEmSelect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.flooderEmSelect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.flooderEmSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.flooderEmSelect.Font = new System.Drawing.Font("Poppins", 8F);
            this.flooderEmSelect.ForeColor = System.Drawing.Color.DarkRed;
            this.flooderEmSelect.Location = new System.Drawing.Point(247, 348);
            this.flooderEmSelect.Name = "flooderEmSelect";
            this.flooderEmSelect.Size = new System.Drawing.Size(83, 24);
            this.flooderEmSelect.TabIndex = 25;
            this.flooderEmSelect.Text = "Select";
            this.flooderEmSelect.UseVisualStyleBackColor = true;
            this.flooderEmSelect.Click += new System.EventHandler(this.flooderEmSelect_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.ForeColor = System.Drawing.Color.DarkRed;
            this.label27.Location = new System.Drawing.Point(35, 347);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(177, 28);
            this.label27.TabIndex = 24;
            this.label27.Text = "Flooder embed color";
            // 
            // safeBox
            // 
            this.safeBox.AutoSize = true;
            this.safeBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.safeBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.safeBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.safeBox.ForeColor = System.Drawing.Color.DarkRed;
            this.safeBox.Location = new System.Drawing.Point(59, 421);
            this.safeBox.Name = "safeBox";
            this.safeBox.Size = new System.Drawing.Size(90, 26);
            this.safeBox.TabIndex = 23;
            this.safeBox.Text = "Safe mode";
            this.safeBox.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Poppins", 8F);
            this.button6.ForeColor = System.Drawing.Color.DarkRed;
            this.button6.Location = new System.Drawing.Point(274, 403);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 24);
            this.button6.TabIndex = 22;
            this.button6.Text = "Stopped";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Poppins", 8F);
            this.button5.ForeColor = System.Drawing.Color.DarkRed;
            this.button5.Location = new System.Drawing.Point(185, 403);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(83, 24);
            this.button5.TabIndex = 21;
            this.button5.Text = "Start";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.ForeColor = System.Drawing.Color.DarkRed;
            this.label26.Location = new System.Drawing.Point(35, 402);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(147, 28);
            this.label26.TabIndex = 20;
            this.label26.Text = "Webhook flooder";
            // 
            // wdeleteButton
            // 
            this.wdeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wdeleteButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.wdeleteButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.wdeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wdeleteButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.wdeleteButton.ForeColor = System.Drawing.Color.DarkRed;
            this.wdeleteButton.Location = new System.Drawing.Point(180, 467);
            this.wdeleteButton.Name = "wdeleteButton";
            this.wdeleteButton.Size = new System.Drawing.Size(83, 24);
            this.wdeleteButton.TabIndex = 19;
            this.wdeleteButton.Text = "Delete";
            this.wdeleteButton.UseVisualStyleBackColor = true;
            this.wdeleteButton.Click += new System.EventHandler(this.wdeleteButton_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.ForeColor = System.Drawing.Color.DarkRed;
            this.label25.Location = new System.Drawing.Point(35, 466);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(139, 28);
            this.label25.TabIndex = 18;
            this.label25.Text = "Delete webhook";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.ForeColor = System.Drawing.Color.DarkRed;
            this.label24.Location = new System.Drawing.Point(35, 277);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(84, 28);
            this.label24.TabIndex = 17;
            this.label24.Text = "Message";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.ForeColor = System.Drawing.Color.DarkRed;
            this.textBox2.Location = new System.Drawing.Point(37, 305);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(341, 24);
            this.textBox2.TabIndex = 16;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.ForeColor = System.Drawing.Color.DarkRed;
            this.label23.Location = new System.Drawing.Point(35, 195);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 28);
            this.label23.TabIndex = 15;
            this.label23.Text = "Username";
            // 
            // userBox
            // 
            this.userBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.userBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.userBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.userBox.ForeColor = System.Drawing.Color.DarkRed;
            this.userBox.Location = new System.Drawing.Point(37, 223);
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(276, 24);
            this.userBox.TabIndex = 14;
            // 
            // tokenChecker
            // 
            this.tokenChecker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tokenChecker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tokenChecker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tokenChecker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tokenChecker.Font = new System.Drawing.Font("Poppins", 8F);
            this.tokenChecker.ForeColor = System.Drawing.Color.DarkRed;
            this.tokenChecker.Location = new System.Drawing.Point(644, 136);
            this.tokenChecker.Name = "tokenChecker";
            this.tokenChecker.Size = new System.Drawing.Size(83, 24);
            this.tokenChecker.TabIndex = 13;
            this.tokenChecker.Text = "Check";
            this.tokenChecker.UseVisualStyleBackColor = true;
            this.tokenChecker.Click += new System.EventHandler(this.tokenChecker_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label29.ForeColor = System.Drawing.Color.DarkRed;
            this.label29.Location = new System.Drawing.Point(384, 108);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 28);
            this.label29.TabIndex = 12;
            this.label29.Text = "Token";
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Poppins", 8F);
            this.button4.ForeColor = System.Drawing.Color.DarkRed;
            this.button4.Location = new System.Drawing.Point(295, 136);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(83, 24);
            this.button4.TabIndex = 13;
            this.button4.Text = "Check";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // TokenCheckerBox
            // 
            this.TokenCheckerBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.TokenCheckerBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TokenCheckerBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.TokenCheckerBox.ForeColor = System.Drawing.Color.DarkRed;
            this.TokenCheckerBox.Location = new System.Drawing.Point(386, 136);
            this.TokenCheckerBox.Name = "TokenCheckerBox";
            this.TokenCheckerBox.Size = new System.Drawing.Size(253, 24);
            this.TokenCheckerBox.TabIndex = 11;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.ForeColor = System.Drawing.Color.DarkRed;
            this.label22.Location = new System.Drawing.Point(35, 108);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(87, 28);
            this.label22.TabIndex = 12;
            this.label22.Text = "Webhook";
            // 
            // miscWebhookBox
            // 
            this.miscWebhookBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.miscWebhookBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.miscWebhookBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.miscWebhookBox.ForeColor = System.Drawing.Color.DarkRed;
            this.miscWebhookBox.Location = new System.Drawing.Point(37, 136);
            this.miscWebhookBox.Name = "miscWebhookBox";
            this.miscWebhookBox.Size = new System.Drawing.Size(253, 24);
            this.miscWebhookBox.TabIndex = 11;
            // 
            // gbBox
            // 
            this.gbBox.AutoSize = true;
            this.gbBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gbBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gbBox.ForeColor = System.Drawing.Color.DarkRed;
            this.gbBox.Location = new System.Drawing.Point(239, 40);
            this.gbBox.Name = "gbBox";
            this.gbBox.Size = new System.Drawing.Size(42, 26);
            this.gbBox.TabIndex = 10;
            this.gbBox.Text = "GB";
            this.gbBox.UseVisualStyleBackColor = true;
            this.gbBox.CheckedChanged += new System.EventHandler(this.gbBox_CheckedChanged);
            // 
            // mbBox
            // 
            this.mbBox.AutoSize = true;
            this.mbBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mbBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mbBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mbBox.ForeColor = System.Drawing.Color.DarkRed;
            this.mbBox.Location = new System.Drawing.Point(191, 40);
            this.mbBox.Name = "mbBox";
            this.mbBox.Size = new System.Drawing.Size(43, 26);
            this.mbBox.TabIndex = 9;
            this.mbBox.Text = "MB";
            this.mbBox.UseVisualStyleBackColor = true;
            this.mbBox.CheckedChanged += new System.EventHandler(this.mbBox_CheckedChanged);
            // 
            // kbBox
            // 
            this.kbBox.AutoSize = true;
            this.kbBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kbBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kbBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kbBox.ForeColor = System.Drawing.Color.DarkRed;
            this.kbBox.Location = new System.Drawing.Point(147, 40);
            this.kbBox.Name = "kbBox";
            this.kbBox.Size = new System.Drawing.Size(40, 26);
            this.kbBox.TabIndex = 8;
            this.kbBox.Text = "KB";
            this.kbBox.UseVisualStyleBackColor = true;
            this.kbBox.CheckedChanged += new System.EventHandler(this.kbBox_CheckedChanged);
            // 
            // pumpPathBox
            // 
            this.pumpPathBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.pumpPathBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pumpPathBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pumpPathBox.ForeColor = System.Drawing.Color.DarkRed;
            this.pumpPathBox.Location = new System.Drawing.Point(161, 67);
            this.pumpPathBox.Name = "pumpPathBox";
            this.pumpPathBox.ReadOnly = true;
            this.pumpPathBox.Size = new System.Drawing.Size(375, 24);
            this.pumpPathBox.TabIndex = 1;
            // 
            // minerSite
            // 
            this.minerSite.Controls.Add(this.label37);
            this.minerSite.Controls.Add(this.label52);
            this.minerSite.Controls.Add(this.label53);
            this.minerSite.Controls.Add(this.textBox1);
            this.minerSite.Controls.Add(this.label54);
            this.minerSite.Controls.Add(this.textBox3);
            this.minerSite.Controls.Add(this.checkBox2);
            this.minerSite.Controls.Add(this.checkBox3);
            this.minerSite.Controls.Add(this.checkBox4);
            this.minerSite.Controls.Add(this.label57);
            this.minerSite.Controls.Add(this.textBox6);
            this.minerSite.Location = new System.Drawing.Point(193, 43);
            this.minerSite.Name = "minerSite";
            this.minerSite.Size = new System.Drawing.Size(751, 522);
            this.minerSite.TabIndex = 18;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label37.ForeColor = System.Drawing.Color.DarkRed;
            this.label37.Location = new System.Drawing.Point(35, 276);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(98, 28);
            this.label37.TabIndex = 19;
            this.label37.Text = "CPU usage";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label52.ForeColor = System.Drawing.Color.DarkRed;
            this.label52.Location = new System.Drawing.Point(35, 375);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(600, 84);
            this.label52.TabIndex = 18;
            this.label52.Text = "1. Setup your pool (ex. pool.minergate.com:443)\r\n2. Setup your username. If you\'r" +
    "e using minergate fill in your email address.\r\n3. To setup workers\' name change " +
    "password variable.";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label53.ForeColor = System.Drawing.Color.DarkRed;
            this.label53.Location = new System.Drawing.Point(35, 197);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(88, 28);
            this.label53.TabIndex = 17;
            this.label53.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkRed;
            this.textBox1.Location = new System.Drawing.Point(37, 225);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(389, 24);
            this.textBox1.TabIndex = 16;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label54.ForeColor = System.Drawing.Color.DarkRed;
            this.label54.Location = new System.Drawing.Point(35, 115);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(94, 28);
            this.label54.TabIndex = 15;
            this.label54.Text = "Username";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox3.ForeColor = System.Drawing.Color.DarkRed;
            this.textBox3.Location = new System.Drawing.Point(37, 143);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(389, 24);
            this.textBox3.TabIndex = 14;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox2.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkBox2.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBox2.Location = new System.Drawing.Point(156, 297);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(50, 26);
            this.checkBox2.TabIndex = 10;
            this.checkBox2.Text = "75%";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox3.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkBox3.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBox3.Location = new System.Drawing.Point(102, 297);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(51, 26);
            this.checkBox3.TabIndex = 9;
            this.checkBox3.Text = "50%";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox4.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkBox4.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBox4.Location = new System.Drawing.Point(49, 297);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(50, 26);
            this.checkBox4.TabIndex = 8;
            this.checkBox4.Text = "25%";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label57.ForeColor = System.Drawing.Color.DarkRed;
            this.label57.Location = new System.Drawing.Point(35, 39);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(111, 28);
            this.label57.TabIndex = 2;
            this.label57.Text = "Monero pool";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox6.ForeColor = System.Drawing.Color.DarkRed;
            this.textBox6.Location = new System.Drawing.Point(37, 67);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(499, 24);
            this.textBox6.TabIndex = 1;
            // 
            // ratSite
            // 
            this.ratSite.Controls.Add(this.ratCompileButton);
            this.ratSite.Controls.Add(this.label45);
            this.ratSite.Controls.Add(this.insertButton);
            this.ratSite.Controls.Add(this.label43);
            this.ratSite.Controls.Add(this.pipBox);
            this.ratSite.Controls.Add(this.label42);
            this.ratSite.Controls.Add(this.ratTokenBox);
            this.ratSite.Controls.Add(this.label40);
            this.ratSite.Controls.Add(this.ratInstallButton);
            this.ratSite.Controls.Add(this.label41);
            this.ratSite.Controls.Add(this.label44);
            this.ratSite.Controls.Add(this.rURLBox);
            this.ratSite.Location = new System.Drawing.Point(193, 43);
            this.ratSite.Name = "ratSite";
            this.ratSite.Size = new System.Drawing.Size(751, 522);
            this.ratSite.TabIndex = 19;
            // 
            // ratCompileButton
            // 
            this.ratCompileButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ratCompileButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ratCompileButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ratCompileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratCompileButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.ratCompileButton.ForeColor = System.Drawing.Color.DarkRed;
            this.ratCompileButton.Location = new System.Drawing.Point(573, 263);
            this.ratCompileButton.Name = "ratCompileButton";
            this.ratCompileButton.Size = new System.Drawing.Size(83, 24);
            this.ratCompileButton.TabIndex = 39;
            this.ratCompileButton.Text = "Compile";
            this.ratCompileButton.UseVisualStyleBackColor = true;
            this.ratCompileButton.Click += new System.EventHandler(this.ratCompileButton_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label45.ForeColor = System.Drawing.Color.DarkRed;
            this.label45.Location = new System.Drawing.Point(454, 262);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(113, 28);
            this.label45.TabIndex = 38;
            this.label45.Text = "Compile RAT";
            // 
            // insertButton
            // 
            this.insertButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.insertButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.insertButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.insertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.insertButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.insertButton.ForeColor = System.Drawing.Color.DarkRed;
            this.insertButton.Location = new System.Drawing.Point(564, 195);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(83, 24);
            this.insertButton.TabIndex = 37;
            this.insertButton.Text = "Insert";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label43.ForeColor = System.Drawing.Color.DarkRed;
            this.label43.Location = new System.Drawing.Point(454, 195);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(104, 28);
            this.label43.TabIndex = 36;
            this.label43.Text = "Insert token";
            // 
            // pipBox
            // 
            this.pipBox.AutoSize = true;
            this.pipBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pipBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pipBox.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pipBox.ForeColor = System.Drawing.Color.DarkRed;
            this.pipBox.Location = new System.Drawing.Point(59, 215);
            this.pipBox.Name = "pipBox";
            this.pipBox.Size = new System.Drawing.Size(96, 26);
            this.pipBox.TabIndex = 35;
            this.pipBox.Text = "PIP Installed";
            this.pipBox.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label42.ForeColor = System.Drawing.Color.DarkRed;
            this.label42.Location = new System.Drawing.Point(22, 100);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(153, 28);
            this.label42.TabIndex = 34;
            this.label42.Text = "Discord Bot Token";
            // 
            // ratTokenBox
            // 
            this.ratTokenBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.ratTokenBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ratTokenBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ratTokenBox.ForeColor = System.Drawing.Color.DarkRed;
            this.ratTokenBox.Location = new System.Drawing.Point(24, 128);
            this.ratTokenBox.Name = "ratTokenBox";
            this.ratTokenBox.Size = new System.Drawing.Size(703, 24);
            this.ratTokenBox.TabIndex = 33;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label40.ForeColor = System.Drawing.Color.DarkRed;
            this.label40.Location = new System.Drawing.Point(22, 195);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(215, 28);
            this.label40.TabIndex = 32;
            this.label40.Text = "Requirements installation";
            // 
            // ratInstallButton
            // 
            this.ratInstallButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ratInstallButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ratInstallButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ratInstallButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratInstallButton.Font = new System.Drawing.Font("Poppins", 8F);
            this.ratInstallButton.ForeColor = System.Drawing.Color.DarkRed;
            this.ratInstallButton.Location = new System.Drawing.Point(243, 195);
            this.ratInstallButton.Name = "ratInstallButton";
            this.ratInstallButton.Size = new System.Drawing.Size(83, 24);
            this.ratInstallButton.TabIndex = 31;
            this.ratInstallButton.Text = "Install";
            this.ratInstallButton.UseVisualStyleBackColor = true;
            this.ratInstallButton.Click += new System.EventHandler(this.ratInstallButton_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label41.ForeColor = System.Drawing.Color.DarkRed;
            this.label41.Location = new System.Drawing.Point(7, 273);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(538, 242);
            this.label41.TabIndex = 18;
            this.label41.Text = resources.GetString("label41.Text");
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label44.ForeColor = System.Drawing.Color.DarkRed;
            this.label44.Location = new System.Drawing.Point(22, 23);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(67, 28);
            this.label44.TabIndex = 2;
            this.label44.Text = "RAT Url";
            // 
            // rURLBox
            // 
            this.rURLBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.rURLBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rURLBox.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rURLBox.ForeColor = System.Drawing.Color.DarkRed;
            this.rURLBox.Location = new System.Drawing.Point(24, 51);
            this.rURLBox.Name = "rURLBox";
            this.rURLBox.Size = new System.Drawing.Size(703, 24);
            this.rURLBox.TabIndex = 1;
            // 
            // qrSite
            // 
            this.qrSite.Controls.Add(this.label51);
            this.qrSite.Controls.Add(this.button7);
            this.qrSite.Controls.Add(this.label50);
            this.qrSite.Controls.Add(this.qrStartBtn);
            this.qrSite.Controls.Add(this.label46);
            this.qrSite.Location = new System.Drawing.Point(193, 43);
            this.qrSite.Name = "qrSite";
            this.qrSite.Size = new System.Drawing.Size(751, 522);
            this.qrSite.TabIndex = 20;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label51.ForeColor = System.Drawing.Color.DarkRed;
            this.label51.Location = new System.Drawing.Point(20, 143);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(507, 110);
            this.label51.TabIndex = 46;
            this.label51.Text = "1. Install python3.\r\n2. Install Google Chrome.\r\n3. Click install button.\r\n4. Clic" +
    "k start QR grabber button.\r\n5. Go to (\'AppData/Discord AIO/QRGrabber\') and take " +
    "< discord_gif.png > from there.";
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Poppins", 8F);
            this.button7.ForeColor = System.Drawing.Color.DarkRed;
            this.button7.Location = new System.Drawing.Point(207, 32);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 24);
            this.button7.TabIndex = 45;
            this.button7.Text = "Install";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label50.ForeColor = System.Drawing.Color.DarkRed;
            this.label50.Location = new System.Drawing.Point(19, 32);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(170, 28);
            this.label50.TabIndex = 44;
            this.label50.Text = "Install requirements";
            // 
            // qrStartBtn
            // 
            this.qrStartBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qrStartBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.qrStartBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.qrStartBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qrStartBtn.Font = new System.Drawing.Font("Poppins", 8F);
            this.qrStartBtn.ForeColor = System.Drawing.Color.DarkRed;
            this.qrStartBtn.Location = new System.Drawing.Point(207, 86);
            this.qrStartBtn.Name = "qrStartBtn";
            this.qrStartBtn.Size = new System.Drawing.Size(83, 24);
            this.qrStartBtn.TabIndex = 39;
            this.qrStartBtn.Text = "Start";
            this.qrStartBtn.UseVisualStyleBackColor = true;
            this.qrStartBtn.Click += new System.EventHandler(this.qrStartBtn_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label46.ForeColor = System.Drawing.Color.DarkRed;
            this.label46.Location = new System.Drawing.Point(19, 87);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(148, 28);
            this.label46.TabIndex = 38;
            this.label46.Text = "Start QR Grabber";
            // 
            // minimizeBtn
            // 
            this.minimizeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeBtn.FlatAppearance.BorderSize = 0;
            this.minimizeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimizeBtn.ForeColor = System.Drawing.Color.DarkRed;
            this.minimizeBtn.Location = new System.Drawing.Point(893, 6);
            this.minimizeBtn.Name = "minimizeBtn";
            this.minimizeBtn.Size = new System.Drawing.Size(25, 25);
            this.minimizeBtn.TabIndex = 3;
            this.minimizeBtn.Text = "_";
            this.minimizeBtn.UseVisualStyleBackColor = true;
            this.minimizeBtn.Click += new System.EventHandler(this.minimizeBtn_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label47.ForeColor = System.Drawing.Color.DarkRed;
            this.label47.Location = new System.Drawing.Point(40, 289);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(129, 34);
            this.label47.TabIndex = 11;
            this.label47.Text = "AppData fix:";
            // 
            // fixButton
            // 
            this.fixButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fixButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fixButton.Font = new System.Drawing.Font("Poppins", 9F);
            this.fixButton.ForeColor = System.Drawing.Color.DarkRed;
            this.fixButton.Location = new System.Drawing.Point(175, 291);
            this.fixButton.Name = "fixButton";
            this.fixButton.Size = new System.Drawing.Size(58, 28);
            this.fixButton.TabIndex = 8;
            this.fixButton.Text = "Fix";
            this.fixButton.UseVisualStyleBackColor = true;
            this.fixButton.Click += new System.EventHandler(this.fixButton_Click);
            // 
            // dAIOmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.ClientSize = new System.Drawing.Size(951, 577);
            this.Controls.Add(this.navLabel);
            this.Controls.Add(this.minimizeBtn);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.ratSite);
            this.Controls.Add(this.qrSite);
            this.Controls.Add(this.settingsSite);
            this.Controls.Add(this.additionalSite);
            this.Controls.Add(this.miscSite);
            this.Controls.Add(this.minerSite);
            this.Controls.Add(this.inspectorSite);
            this.Controls.Add(this.mainSite);
            this.Controls.Add(this.sidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "dAIOmain";
            this.Text = "Discord AIO";
            this.Load += new System.EventHandler(this.dAIOmain_Load);
            this.ResizeEnd += new System.EventHandler(this.dAIOmain_ResizeEnd);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.Move += new System.EventHandler(this.dAIOmain_Move);
            this.sidePanel.ResumeLayout(false);
            this.sidePanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).EndInit();
            this.settingsSite.ResumeLayout(false);
            this.settingsSite.PerformLayout();
            this.mainSite.ResumeLayout(false);
            this.mainSite.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.embedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconBox)).EndInit();
            this.inspectorSite.ResumeLayout(false);
            this.inspectorSite.PerformLayout();
            this.additionalSite.ResumeLayout(false);
            this.additionalSite.PerformLayout();
            this.miscSite.ResumeLayout(false);
            this.miscSite.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avatarBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flooderEmbed)).EndInit();
            this.minerSite.ResumeLayout(false);
            this.minerSite.PerformLayout();
            this.ratSite.ResumeLayout(false);
            this.ratSite.PerformLayout();
            this.qrSite.ResumeLayout(false);
            this.qrSite.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnParty;
        private System.Windows.Forms.Button btnMap;
        private System.Windows.Forms.Button btnWork;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.PictureBox logoBox;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel settingsSite;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label versionLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button redButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button shNo;
        private System.Windows.Forms.Button shYes;
        private System.Windows.Forms.Button btnUpdates;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel mainSite;
        private System.Windows.Forms.TextBox webhookBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button webhookCheck;
        private System.Windows.Forms.PictureBox iconBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button iconUpload;
        private System.Windows.Forms.Label navLabel;
        private System.Windows.Forms.Button englishButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button polishButton;
        private System.Windows.Forms.Button frenchButton;
        private System.Windows.Forms.Button russianButton;
        private System.Windows.Forms.Button turkishButton;
        private System.Windows.Forms.Button spanishButton;
        private System.Windows.Forms.Button cloneButton;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.Label fileinfoLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buildButton;
        private System.Windows.Forms.PictureBox embedBox;
        private System.Windows.Forms.Button colorSelect;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel inspectorSite;
        private System.Windows.Forms.Button dAIOupload;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox dAIObox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox winBox;
        private System.Windows.Forms.TextBox tokenBox;
        private System.Windows.Forms.TextBox macBox;
        private System.Windows.Forms.TextBox ipBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button exportCredentials;
        private System.Windows.Forms.Panel additionalSite;
        private System.Windows.Forms.CheckBox hidesBox;
        private System.Windows.Forms.CheckBox blockerBox;
        private System.Windows.Forms.CheckBox pluginBox;
        private System.Windows.Forms.CheckBox bsodBox;
        private System.Windows.Forms.CheckBox taskmanagerBox;
        private System.Windows.Forms.CheckBox defenderBox;
        private System.Windows.Forms.CheckBox startupBox;
        private System.Windows.Forms.CheckBox errorBox;
        private System.Windows.Forms.CheckBox obfuscateBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox swifiBox;
        private System.Windows.Forms.CheckBox sVpnBox;
        private System.Windows.Forms.CheckBox sbrCookiesBox;
        private System.Windows.Forms.CheckBox sbrpassBox;
        private System.Windows.Forms.CheckBox swinkeyBox;
        private System.Windows.Forms.CheckBox inputdBox;
        private System.Windows.Forms.CheckBox jumpscareBox;
        private System.Windows.Forms.CheckBox cryptoBox;
        private System.Windows.Forms.CheckBox sbrhisBox;
        private System.Windows.Forms.CheckBox ransomBox;
        private System.Windows.Forms.TextBox fakeMessageBox;
        private System.Windows.Forms.TextBox faketitleBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private ScintillaNET.Scintilla pluginSource;
        private System.Windows.Forms.TextBox pumpBox;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button pumpButton;
        private System.Windows.Forms.Panel miscSite;
        private System.Windows.Forms.CheckBox gbBox;
        private System.Windows.Forms.CheckBox mbBox;
        private System.Windows.Forms.CheckBox kbBox;
        private System.Windows.Forms.TextBox pumpPathBox;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox miscWebhookBox;
        private System.Windows.Forms.Button wdeleteButton;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox userBox;
        private System.Windows.Forms.CheckBox safeBox;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox flooderEmbed;
        private System.Windows.Forms.Button flooderEmSelect;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label tVLabel;
        private System.Windows.Forms.Label tMFALabel;
        private System.Windows.Forms.Label tIDLabel;
        private System.Windows.Forms.Label tPhoneLabel;
        private System.Windows.Forms.Label tEmailLabel;
        private System.Windows.Forms.Label tNameLabel;
        private System.Windows.Forms.PictureBox avatarBox;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button tokenChecker;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox TokenCheckerBox;
        private System.Windows.Forms.Label buildingLabel;
        private System.Windows.Forms.CheckBox dinternetBox;
        private System.Windows.Forms.Panel minerSite;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label translateLabel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label checkingLabel;
        private System.Windows.Forms.CheckBox ratBox;
        private System.Windows.Forms.Button ratButton;
        private System.Windows.Forms.Panel ratSite;
        private System.Windows.Forms.Button ratInstallButton;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox rURLBox;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox ratTokenBox;
        private System.Windows.Forms.CheckBox pipBox;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button ratCompileButton;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.CheckBox nitroBox;
        private System.Windows.Forms.CheckBox cmdBox;
        private System.Windows.Forms.CheckBox wizardBox;
        private System.Windows.Forms.Label page2;
        private System.Windows.Forms.Label page1;
        private System.Windows.Forms.Button qrButton;
        private System.Windows.Forms.Panel qrSite;
        private System.Windows.Forms.Button qrStartBtn;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button minimizeBtn;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button fixButton;
    }
}

