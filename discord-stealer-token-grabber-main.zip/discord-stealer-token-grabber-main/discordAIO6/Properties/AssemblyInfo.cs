﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Discord AIO")]
[assembly: AssemblyDescription("Discord AIO")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Nyxon")]
[assembly: AssemblyProduct("Discord AIO")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("408702e5-aac4-44fd-a589-6547d02fc510")]
[assembly: AssemblyVersion("0.6.3.0")]
[assembly: AssemblyFileVersion("0.6.3.0")]
